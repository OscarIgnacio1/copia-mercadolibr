# Variations

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**price** | **int** |  | [optional] 
**attribute_combinations** | [**list[VariationsAttributeCombinations]**](VariationsAttributeCombinations.md) |  | [optional] 
**available_quantity** | **int** |  | [optional] 
**sold_quantity** | **int** |  | [optional] 
**picture_ids** | **list[str]** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


