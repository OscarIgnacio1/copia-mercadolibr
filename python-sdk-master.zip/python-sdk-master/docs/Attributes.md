# Attributes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** |  | [optional] 
**name** | **str** |  | [optional] 
**value_id** | **str** |  | [optional] 
**value_name** | **str** |  | [optional] 
**value_struct** | [**AttributesValueStruct**](AttributesValueStruct.md) |  | [optional] 
**values** | [**list[AttributesValues]**](AttributesValues.md) |  | [optional] 
**attribute_group_id** | **str** |  | [optional] 
**attribute_group_name** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


